function displayMenu() {
    var x = document.getElementById("mega_menu");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

